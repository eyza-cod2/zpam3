Installation

In order to sucessfully install pam on your server, follow these steps:

Extract folders with files into following locations:
	- pb/pbsvuser.cfg
	- mods/zpam310_beta6/zpam310_beta6.iwd
	- mods/zpam310_beta6/pam_pub.cfg * optional - this file is used only when you are running public server

Add +set fs_game "mods/zpam310_beta6" into command line



Contact
Write message on discord CyberGamer Europe in #cod2-zpam-3 channel.
Or add me on discord eyza#7930
Or write me on email kratas.tom@seznam.cz

https://github.com/eyza-cod2/zpam3
