Installation
Extract folders with files into following locations:
	- ./pb/pbsvuser.cfg
	- ./main/zpam320.iwd
	- ./main/mp_toujane_fix_v1.iwd
	- ./main/mp_burgundy_fix_v1.iwd
	- ./main/server.cfg

Enable downloading via cvar sv_wwwDownload 1 and specify a download url via cvar sv_wwwBaseURL "url"
For fast server config exec server.cfg

More info at: https://github.com/eyza-cod2/zpam3


Contact
Write message on discord LetsPlay Europe in #cod2-zpam-3 channel.
Or add me on discord eyza#7930
Or write me on email kratas.tom@seznam.cz
