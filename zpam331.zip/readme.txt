Installation
Extract files into following locations:
	- ./Call of Duty 2/main/zpam331.iwd
	- ./Call of Duty 2/main/zpam_maps_v2.iwd (*required only for 1.3 game version)
	- ./Call of Duty 2/main/server.cfg

Add +exec server.cfg into command line arguments and edit the server.cfg file to configure your server.

For game version 1.3:
	- Mappack file zpam_maps_v2.iwd needs to be included in main folder. What is zpam_maps_v1.iwd file?
	- Fast download must be enabled via these settings (custom URL may be used):
		- sv_wwwDownload 1
		- sv_wwwBaseURL "http://cod2x.me/zpam"
	- This is to make sure that maps are downloaded in fast way for players

More info at: https://github.com/eyza-cod2/zpam3

Contact
Write message on discord TLS CoD2 Community in #zpam3-chat channel. https://discord.gg/HDsC6u5k6y
Or add me on discord eyza#7930
Or write me on email kratas.tom@seznam.cz
