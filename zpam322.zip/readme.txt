Installation
Extract folders with files into following locations:
	- ./pb/pbsvuser.cfg
	- ./main/zpam322.iwd
	- ./main/mp_toujane_fix_v2.iwd
	- ./main/mp_burgundy_fix_v1.iwd
	- ./main/server.cfg
	- ./main/public.cfg

Add '+exec server.cfg' into command line arguments and edit the server.cfg file to configure your server
If you are running public server, add '+exec public.cfg' into command line arguments and edit the public.cfg file to configure your public server
If you use these .cfg files, make sure no other .cfg files are executed!

More info at: https://github.com/eyza-cod2/zpam3

Contact
Write message on discord LetsPlay Europe in #cod2-zpam-3 channel.
Or add me on discord eyza#7930
Or write me on email kratas.tom@seznam.cz
