Installation
Extract files into following locations:
	- ./Call of Duty 2/main/zpam330.iwd
	- ./Call of Duty 2/main/zpam_maps_v1.iwd
	- ./Call of Duty 2/main/server.cfg

Add '+exec server.cfg' into command line arguments and edit the server.cfg file to configure your server

More info at: https://github.com/eyza-cod2/zpam3

Contact
Write message on discord FPS Challange in #cod2-zpam3 channel. https://discord.gg/yBzx4AJ9b7
Or add me on discord eyza#7930
Or write me on email kratas.tom@seznam.cz